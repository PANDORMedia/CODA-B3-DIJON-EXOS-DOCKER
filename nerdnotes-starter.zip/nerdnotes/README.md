# nerdnotes

Petite API Python de prise de notes. C'est l'application fil rouge du module Docker + Kubernetes.

## Routes

| Route      | Methode | Role                                                   |
|------------|---------|--------------------------------------------------------|
| `/`        | GET     | Nom, version, hostname et proprietaire de l'instance   |
| `/notes`   | GET     | Liste les notes                                        |
| `/notes`   | POST    | Ajoute une note : `{"text": "..."}`                    |
| `/health`  | GET     | Etat de sante                                          |
| `/metrics` | GET     | Metriques au format Prometheus                         |

## Configuration

| Variable       | Defaut    | Effet                                                    |
|----------------|-----------|----------------------------------------------------------|
| `OWNER`        | `anonyme` | Proprietaire affiche sur `/`                             |
| `DATABASE_URL` | (vide)    | Si defini, les notes sont stockees dans Postgres         |

Sans `DATABASE_URL`, les notes sont gardees en memoire.

## Lancer l'app

Elle se lance avec gunicorn :

    gunicorn -b 0.0.0.0:5000 app:app

A toi d'ecrire le `Dockerfile`.
