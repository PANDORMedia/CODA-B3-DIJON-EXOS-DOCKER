"""nerdnotes : petite API de prise de notes, fil rouge du module Docker + Kubernetes."""
import os
import socket
import threading
import time

from flask import Flask, Response, jsonify, request
from prometheus_client import CONTENT_TYPE_LATEST, Counter, generate_latest

VERSION = "1.0"
DATABASE_URL = os.getenv("DATABASE_URL")

app = Flask(__name__)
app.json.compact = False

REQUESTS = Counter("nerdnotes_requests_total", "Requetes HTTP recues", ["method", "route"])

# Stockage en memoire, utilise quand DATABASE_URL n'est pas defini
_memory = []
_lock = threading.Lock()
_db_ready = False


def _connect():
    import psycopg
    return psycopg.connect(DATABASE_URL, autocommit=True)


def _ensure_db():
    global _db_ready
    if _db_ready:
        return
    with _connect() as conn:
        conn.execute(
            "CREATE TABLE IF NOT EXISTS notes ("
            "id SERIAL PRIMARY KEY, text TEXT NOT NULL, created_at TIMESTAMPTZ DEFAULT now())"
        )
    _db_ready = True


@app.before_request
def _count():
    route = request.url_rule.rule if request.url_rule else "inconnue"
    REQUESTS.labels(request.method, route).inc()


@app.get("/")
def index():
    return jsonify(
        app="nerdnotes",
        version=VERSION,
        hostname=socket.gethostname(),
        owner=os.getenv("OWNER", "anonyme"),
        storage="postgres" if DATABASE_URL else "memoire",
    )


@app.get("/notes")
def list_notes():
    if DATABASE_URL:
        _ensure_db()
        with _connect() as conn:
            rows = conn.execute("SELECT id, text, created_at FROM notes ORDER BY id").fetchall()
        return jsonify([{"id": r[0], "text": r[1], "created_at": r[2].isoformat()} for r in rows])
    with _lock:
        return jsonify(list(_memory))


@app.post("/notes")
def add_note():
    data = request.get_json(silent=True) or {}
    text = str(data.get("text", "")).strip()
    if not text:
        return jsonify(error="le champ 'text' est obligatoire"), 400
    if DATABASE_URL:
        _ensure_db()
        with _connect() as conn:
            row = conn.execute(
                "INSERT INTO notes (text) VALUES (%s) RETURNING id, created_at", (text,)
            ).fetchone()
        return jsonify(id=row[0], text=text, created_at=row[1].isoformat()), 201
    with _lock:
        note = {"id": len(_memory) + 1, "text": text, "created_at": time.strftime("%Y-%m-%dT%H:%M:%S")}
        _memory.append(note)
    return jsonify(note), 201


@app.get("/health")
def health():
    if DATABASE_URL:
        try:
            with _connect() as conn:
                conn.execute("SELECT 1")
        except Exception as exc:  # base injoignable
            return jsonify(status="ko", detail=str(exc)), 503
    return jsonify(status="ok")


@app.get("/metrics")
def metrics():
    return Response(generate_latest(), mimetype=CONTENT_TYPE_LATEST)


@app.get("/burn")
def burn():
    """Consomme du CPU pendant ?seconds=N (30 max). Sert a declencher l'autoscaling."""
    seconds = min(float(request.args.get("seconds", 5)), 30)
    end = time.time() + seconds
    n = 0
    while time.time() < end:
        n += 1
    return jsonify(burned_seconds=seconds, iterations=n)


if __name__ == "__main__":
    app.run(port=5000)
